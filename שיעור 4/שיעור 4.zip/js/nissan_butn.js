function blue(){
   var blueBut = document.getElementById("blue").click ;
  
}
